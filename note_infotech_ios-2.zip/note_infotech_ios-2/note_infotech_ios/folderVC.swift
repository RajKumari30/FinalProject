//
//  ViewController.swift
//  note_infotech_iOS
//
//  Created by infotech on 02/02/21.
//  Copyright © 2021 infotech. All rights reserved.
//

import UIKit
import CoreData

class folderVC: UITableViewController {

    var folders = [Folder]()
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.tableFooterView = UIView()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        let request: NSFetchRequest<Folder> = Folder.fetchRequest()   
        do{
            folders = try context.fetch(request)
        }catch{
            print("Error Loading Folders \(error.localizedDescription)")
        }
        tableView.reloadData()
    }
    
    //MARK: - Add folder Button

    @IBAction func addFolderBtnPressed(_ sender: UIBarButtonItem) {
        var textField = UITextField()
        let alert = UIAlertController(title: "Add new Folder", message: "Please give a name", preferredStyle: .alert)
        let addAction = UIAlertAction(title: "ADD", style: .default) { (action) in
            let folderNames = self.folders.map{$0.name?.lowercased()}
            guard !folderNames.contains(textField.text?.lowercased()) else {self.showAlert(); return}
            let newFolder = Folder(context: self.context)
            newFolder.name = textField.text!
            self.folders.append(newFolder)
            self.saveFolders()
        }
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
        alert.addAction(addAction)
        alert.addAction(cancelAction)
        alert.addTextField { (field) in
            textField = field
            textField.placeholder = "Please Provide folder name"
        }
        present(alert, animated: true, completion: nil)
    }
    
    func showAlert() {
        let alert = UIAlertController(title: "Name taken", message: "Please Choose Another Name", preferredStyle: .alert)
        let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
        alert.addAction(okAction)
        present(alert, animated: true, completion: nil)
    }
    
    //MARK: - Save Folder Func
    func saveFolders() {
        do{
            try context.save()
            tableView.reloadData()
        }catch{
            print("Erro saving the folder \(error.localizedDescription)")
        }
    }
    
    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let destination = segue.destination as! NoteVC
        if let indexPath = tableView.indexPathForSelectedRow{
            destination.selectedFolder = folders[indexPath.row]
        }
    }
}

// MARK: - Table view data source
extension folderVC {

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return folders.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "folder_cell", for: indexPath)
        cell.textLabel?.text = folders[indexPath.row].name
        cell.detailTextLabel?.text = "\(folders[indexPath.row].notes?.count ?? 0)"
        cell.imageView?.image = UIImage(systemName: "Folder")
        cell.selectionStyle = .none
        return cell
    }
    
}

//
//  AddNoteViewController.swift
//  note_infotech_iOS
//
//  Created by infotech on 02/02/21.
//  Copyright © 2021 infotech. All rights reserved.
//

import UIKit
import CoreLocation

class AddNoteVC: UIViewController, CLLocationManagerDelegate, UIImagePickerControllerDelegate, UINavigationControllerDelegate  {
    
    @IBOutlet weak var noteTextView: UITextView!
    @IBOutlet weak var imageViewNotes: UIImageView!
    @IBOutlet weak var labelCoordinates: UILabel!

    var locationManager = CLLocationManager()

    var selectedNote: Note?{
        didSet{
           isEditMode = true
        }
    }
    
    var isEditMode: Bool = false
    
    weak var delegate: NoteVC?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.noteTextView.text = selectedNote?.title
        self.labelCoordinates.text = selectedNote?.location
        if let image = self.getImage(selectedNote?.imageName ?? "") {
            self.imageViewNotes.image = image
        }
        else {
            noteTextView.becomeFirstResponder()
        }
        
        self.locationManager.requestAlwaysAuthorization()
        self.locationManager.requestWhenInUseAuthorization()
        if CLLocationManager.locationServicesEnabled() {
            locationManager.delegate = self
            locationManager.desiredAccuracy = kCLLocationAccuracyBest
            locationManager.startUpdatingLocation()
        }
        
        let doneToolbar: UIToolbar = UIToolbar(frame: CGRect.init(x: 0, y: 0, width: UIScreen.main.bounds.width, height: 50))
              doneToolbar.barStyle = .default

              let flexSpace = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
              let done: UIBarButtonItem = UIBarButtonItem(title: "Done", style: .done, target: self, action: #selector(self.doneButtonAction))

              let items = [flexSpace, done]
              doneToolbar.items = items
              doneToolbar.sizeToFit()

              noteTextView.inputAccessoryView = doneToolbar
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        if isEditMode{
            delegate!.deleteNote(note: selectedNote!)
        }
        delegate!.updateNote(with : noteTextView.text, image: imageViewNotes.image, location: labelCoordinates.text ?? "")
    }
    
    @IBAction func addPhoto(_ sender: UIBarButtonItem) {
        noteTextView.resignFirstResponder()
        let cameraPicker = UIImagePickerController()
        if(UIImagePickerController .isSourceTypeAvailable(.savedPhotosAlbum)){
            cameraPicker.sourceType = .photoLibrary
            cameraPicker.delegate = self
            self.present(cameraPicker, animated: true, completion: nil)
        }
        else {
        }
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        noteTextView.resignFirstResponder()
    }
    
    @objc func doneButtonAction(){
        noteTextView.resignFirstResponder()
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations
        locations: [CLLocation]) {
        let locValue:CLLocationCoordinate2D = manager.location!.coordinate
        let val = "Latitude - \(locValue.latitude)  \nLongitude - \(locValue.longitude)"
        self.labelCoordinates.text = val
    }
    
    func getImage(_ fileName: String)-> UIImage? {
           let documentsDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
           let fileURL = documentsDirectory.appendingPathComponent(fileName)
           if FileManager.default.fileExists(atPath: fileURL.path){
               if let data = try? Data(contentsOf: fileURL) {
                   return UIImage(data: data)
               }
           }
           return nil
       }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        let info = convertFromUIImagePickerControllerInfoKeyDictionary(info)
        picker.dismiss(animated: true, completion: nil)
        let image = (info[convertFromUIImagePickerControllerInfoKey(UIImagePickerController.InfoKey.originalImage)] as! UIImage)
        self.imageViewNotes.image = image
    }
    
    func convertFromUIImagePickerControllerInfoKeyDictionary(_ input: [UIImagePickerController.InfoKey: Any]) -> [String: Any] {
        return Dictionary(uniqueKeysWithValues: input.map {key, value in (key.rawValue, value)})
    }

    func convertFromUIImagePickerControllerInfoKey(_ input: UIImagePickerController.InfoKey) -> String {
        return input.rawValue
    }
}

